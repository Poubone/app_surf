
  # Surf Score Application

  This is a code bundle for Surf Score Application. The original project is available at https://www.figma.com/design/M5CXczCnwpkzYFS8GQrqIM/Surf-Score-Application.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  