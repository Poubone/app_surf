import { useState, useMemo } from "react";
import {
  Search, ArrowLeft, Wind, Thermometer, Calendar,
  X, Compass, TrendingUp, MapPin, ChevronRight,
  Clock, Zap
} from "lucide-react";

// ─── Types ────────────────────────────────────────────────────────────────────

interface Spot {
  id: string;
  name: string;
  region: string;
  score: number;
  x: number;
  y: number;
  waves: { height: number; period: number; direction: string };
  wind: { speed: number; direction: string; gust: number };
  water: { temp: number };
  tide: string;
  weather: { temp: number; condition: string; emoji: string };
  weeklyScores: number[];
  hourly: { hour: string; score: number; height: number }[];
}

// ─── Data ─────────────────────────────────────────────────────────────────────

const SPOTS: Spot[] = [
  {
    id: "hossegor",
    name: "Hossegor",
    region: "Landes",
    score: 9,
    x: 28, y: 52,
    waves: { height: 2.1, period: 14, direction: "ONO" },
    wind: { speed: 12, direction: "NNO", gust: 18 },
    water: { temp: 19 },
    tide: "Montante · 14h30",
    weather: { temp: 24, condition: "Ensoleillé", emoji: "☀️" },
    weeklyScores: [9, 7, 5, 8, 6, 9, 4],
    hourly: [
      { hour: "06h", score: 6, height: 1.6 },
      { hour: "08h", score: 8, height: 1.9 },
      { hour: "10h", score: 9, height: 2.1 },
      { hour: "12h", score: 9, height: 2.2 },
      { hour: "14h", score: 8, height: 2.0 },
      { hour: "16h", score: 7, height: 1.8 },
      { hour: "18h", score: 5, height: 1.4 },
      { hour: "20h", score: 4, height: 1.1 },
    ],
  },
  {
    id: "biarritz",
    name: "Biarritz",
    region: "Pays Basque",
    score: 7,
    x: 22, y: 68,
    waves: { height: 1.6, period: 12, direction: "O" },
    wind: { speed: 15, direction: "O", gust: 22 },
    water: { temp: 20 },
    tide: "Descendante · 11h45",
    weather: { temp: 23, condition: "Nuageux", emoji: "⛅" },
    weeklyScores: [7, 6, 4, 7, 5, 8, 3],
    hourly: [
      { hour: "06h", score: 5, height: 1.2 },
      { hour: "08h", score: 6, height: 1.4 },
      { hour: "10h", score: 7, height: 1.6 },
      { hour: "12h", score: 7, height: 1.7 },
      { hour: "14h", score: 6, height: 1.5 },
      { hour: "16h", score: 5, height: 1.3 },
      { hour: "18h", score: 4, height: 1.1 },
      { hour: "20h", score: 3, height: 0.9 },
    ],
  },
  {
    id: "lacanau",
    name: "Lacanau",
    region: "Gironde",
    score: 6,
    x: 34, y: 32,
    waves: { height: 1.4, period: 11, direction: "NO" },
    wind: { speed: 20, direction: "NO", gust: 28 },
    water: { temp: 18 },
    tide: "Montante · 13h15",
    weather: { temp: 21, condition: "Couvert", emoji: "☁️" },
    weeklyScores: [6, 5, 3, 6, 7, 5, 2],
    hourly: [
      { hour: "06h", score: 4, height: 1.0 },
      { hour: "08h", score: 5, height: 1.2 },
      { hour: "10h", score: 6, height: 1.4 },
      { hour: "12h", score: 6, height: 1.5 },
      { hour: "14h", score: 5, height: 1.3 },
      { hour: "16h", score: 4, height: 1.1 },
      { hour: "18h", score: 3, height: 0.9 },
      { hour: "20h", score: 2, height: 0.7 },
    ],
  },
  {
    id: "capbreton",
    name: "Capbreton",
    region: "Landes",
    score: 8,
    x: 24, y: 59,
    waves: { height: 1.9, period: 13, direction: "ONO" },
    wind: { speed: 10, direction: "NNO", gust: 14 },
    water: { temp: 19 },
    tide: "Montante · 14h00",
    weather: { temp: 24, condition: "Ensoleillé", emoji: "☀️" },
    weeklyScores: [8, 7, 4, 9, 6, 7, 3],
    hourly: [
      { hour: "06h", score: 5, height: 1.4 },
      { hour: "08h", score: 7, height: 1.7 },
      { hour: "10h", score: 8, height: 1.9 },
      { hour: "12h", score: 9, height: 2.1 },
      { hour: "14h", score: 8, height: 1.9 },
      { hour: "16h", score: 7, height: 1.7 },
      { hour: "18h", score: 5, height: 1.4 },
      { hour: "20h", score: 4, height: 1.1 },
    ],
  },
  {
    id: "anglet",
    name: "Anglet",
    region: "Pays Basque",
    score: 5,
    x: 19, y: 64,
    waves: { height: 1.2, period: 10, direction: "O" },
    wind: { speed: 22, direction: "O", gust: 30 },
    water: { temp: 20 },
    tide: "Descendante · 12h00",
    weather: { temp: 22, condition: "Nuageux", emoji: "⛅" },
    weeklyScores: [5, 4, 3, 5, 6, 4, 2],
    hourly: [
      { hour: "06h", score: 3, height: 0.9 },
      { hour: "08h", score: 4, height: 1.0 },
      { hour: "10h", score: 5, height: 1.2 },
      { hour: "12h", score: 5, height: 1.3 },
      { hour: "14h", score: 4, height: 1.1 },
      { hour: "16h", score: 3, height: 0.9 },
      { hour: "18h", score: 2, height: 0.7 },
      { hour: "20h", score: 2, height: 0.6 },
    ],
  },
  {
    id: "seignosse",
    name: "Seignosse",
    region: "Landes",
    score: 8,
    x: 30, y: 46,
    waves: { height: 2.0, period: 13, direction: "ONO" },
    wind: { speed: 11, direction: "NNO", gust: 16 },
    water: { temp: 19 },
    tide: "Montante · 14h20",
    weather: { temp: 25, condition: "Ensoleillé", emoji: "☀️" },
    weeklyScores: [8, 8, 5, 7, 6, 9, 4],
    hourly: [
      { hour: "06h", score: 5, height: 1.5 },
      { hour: "08h", score: 7, height: 1.8 },
      { hour: "10h", score: 8, height: 2.0 },
      { hour: "12h", score: 9, height: 2.2 },
      { hour: "14h", score: 8, height: 2.0 },
      { hour: "16h", score: 7, height: 1.7 },
      { hour: "18h", score: 5, height: 1.4 },
      { hour: "20h", score: 4, height: 1.1 },
    ],
  },
];

const DAYS = ["Auj.", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim"];

// Derives approximate per-day conditions from a score (1-10)
function getDayConditions(score: number, seed: number) {
  const s = score;
  const height = Math.round((s * 0.22 + 0.15 + (seed % 3) * 0.1) * 10) / 10;
  const period = Math.round(s * 0.9 + 5 + (seed % 2));
  const windSpeed = Math.max(5, Math.round((10 - s) * 2 + 5 - (seed % 3)));
  const gust = windSpeed + Math.round(4 + (seed % 4));
  const waterTemp = 18 + Math.round((seed % 3));
  const dirs = ["O", "NO", "NNO", "ONO", "N", "SO"];
  const waveDir = dirs[seed % dirs.length];
  const windDir = dirs[(seed + 2) % dirs.length];
  const weathers = [
    { temp: 20 + (seed % 7), condition: "Couvert", emoji: "☁️" },
    { temp: 22 + (seed % 5), condition: "Nuageux", emoji: "⛅" },
    { temp: 24 + (seed % 4), condition: "Ensoleillé", emoji: "☀️" },
    { temp: 19 + (seed % 6), condition: "Pluvieux", emoji: "🌧️" },
  ];
  const weather = weathers[seed % weathers.length];
  const tides = ["Montante · 13h00", "Descendante · 11h30", "Montante · 14h45", "Pleine mer · 12h15"];
  const tide = tides[seed % tides.length];

  // Hourly data based on score
  const hourlyBases = [0.6, 0.75, 0.9, 1.0, 0.95, 0.85, 0.65, 0.5];
  const hourly = ["06h", "08h", "10h", "12h", "14h", "16h", "18h", "20h"].map((hour, i) => {
    const mult = hourlyBases[i];
    return {
      hour,
      score: Math.max(1, Math.min(10, Math.round(s * mult))),
      height: Math.round(height * mult * 10) / 10,
    };
  });

  return { height, period, windSpeed, gust, waterTemp, waveDir, windDir, weather, tide, hourly };
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function getScoreColor(score: number): string {
  if (score >= 8) return "#00e5a0";
  if (score >= 6) return "#00c4ff";
  if (score >= 4) return "#ffb84d";
  return "#ff5252";
}

function getScoreLabel(score: number): string {
  if (score >= 8) return "Excellent";
  if (score >= 6) return "Bon";
  if (score >= 4) return "Correct";
  return "Médiocre";
}

// ─── Sub-components ───────────────────────────────────────────────────────────

function ScoreRing({ score, size = 52 }: { score: number; size?: number }) {
  const color = getScoreColor(score);
  const r = (size - 7) / 2;
  const circ = 2 * Math.PI * r;
  const offset = circ - (score / 10) * circ;
  return (
    <div style={{ width: size, height: size }} className="relative flex items-center justify-center shrink-0">
      <svg width={size} height={size} className="-rotate-90" style={{ position: "absolute" }}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth={3.5} />
        <circle
          cx={size / 2} cy={size / 2} r={r}
          fill="none" stroke={color} strokeWidth={3.5}
          strokeDasharray={circ} strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: "stroke-dashoffset 0.6s ease" }}
        />
      </svg>
      <span className="text-sm font-bold relative z-10" style={{ color, fontFamily: "'Space Mono', monospace" }}>
        {score}
      </span>
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  sub,
  color,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub?: string;
  color?: string;
}) {
  return (
    <div
      className="flex flex-col gap-2.5 p-4 rounded-2xl"
      style={{ backgroundColor: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.07)" }}
    >
      <div className="flex items-center gap-2">
        <span style={{ color: color || "#5a7294" }}>{icon}</span>
        <span className="text-xs uppercase tracking-widest text-muted-foreground" style={{ fontFamily: "'Space Mono', monospace", fontSize: "0.65rem" }}>
          {label}
        </span>
      </div>
      <div>
        <div className="text-xl font-bold text-foreground" style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 700 }}>
          {value}
        </div>
        {sub && (
          <div className="text-xs text-muted-foreground mt-0.5" style={{ fontFamily: "'Space Mono', monospace" }}>
            {sub}
          </div>
        )}
      </div>
    </div>
  );
}

function SpotMarker({ spot, onClick, isSelected }: { spot: Spot; onClick: () => void; isSelected: boolean }) {
  const color = getScoreColor(spot.score);
  return (
    <button
      onClick={onClick}
      style={{ left: `${spot.x}%`, top: `${spot.y}%` }}
      className="absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center gap-1 z-10"
    >
      {isSelected && (
        <div
          className="absolute w-14 h-14 rounded-full animate-ping"
          style={{ backgroundColor: color, opacity: 0.15 }}
        />
      )}
      <div
        className="w-10 h-10 rounded-full flex items-center justify-center font-bold shadow-xl border-2 transition-transform duration-200"
        style={{
          backgroundColor: isSelected ? color : `${color}20`,
          borderColor: color,
          color: isSelected ? "#070c16" : color,
          fontFamily: "'Space Mono', monospace",
          fontSize: "0.8rem",
          transform: isSelected ? "scale(1.15)" : "scale(1)",
          boxShadow: `0 0 16px ${color}40`,
          backdropFilter: "blur(8px)",
        }}
      >
        {spot.score}
      </div>
      <span
        className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md whitespace-nowrap"
        style={{
          backgroundColor: "rgba(7,12,22,0.85)",
          color: isSelected ? color : "rgba(232,237,245,0.8)",
          fontFamily: "'Outfit', sans-serif",
          border: `1px solid ${isSelected ? color : "rgba(255,255,255,0.1)"}`,
          backdropFilter: "blur(4px)",
        }}
      >
        {spot.name}
      </span>
    </button>
  );
}

function HourlyBar({ h, maxH }: { h: { hour: string; score: number; height: number }; maxH: number }) {
  const color = getScoreColor(h.score);
  const pct = (h.height / maxH) * 100;
  return (
    <div className="flex flex-col items-center gap-2 flex-1">
      <span className="text-xs font-bold" style={{ color, fontFamily: "'Space Mono', monospace", fontSize: "0.65rem" }}>
        {h.score}
      </span>
      <div className="w-full flex flex-col justify-end rounded-md overflow-hidden" style={{ height: 52, backgroundColor: "rgba(255,255,255,0.04)" }}>
        <div
          className="w-full rounded-t-md transition-all duration-500"
          style={{ height: `${pct}%`, backgroundColor: color, opacity: 0.8 }}
        />
      </div>
      <span className="text-muted-foreground" style={{ fontFamily: "'Space Mono', monospace", fontSize: "0.6rem" }}>
        {h.hour}
      </span>
    </div>
  );
}

// ─── Views ────────────────────────────────────────────────────────────────────

function MapView({
  spots,
  searchQuery,
  setSearchQuery,
  onSpotClick,
  selectedSpotId,
  onWeekly,
}: {
  spots: Spot[];
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  onSpotClick: (spot: Spot) => void;
  selectedSpotId: string | null;
  onWeekly: () => void;
}) {
  return (
    <div className="flex flex-col h-full relative">
      {/* Top bar */}
      <div
        className="relative z-20 flex flex-col gap-3 px-4 pt-12 pb-4"
        style={{
          background: "linear-gradient(to bottom, #070c16 60%, transparent)",
        }}
      >
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-foreground" style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 800, letterSpacing: "-0.02em" }}>
              SurfScore
            </h1>
            <p className="text-xs text-muted-foreground" style={{ fontFamily: "'Space Mono', monospace" }}>
              Côte Atlantique · Auj.
            </p>
          </div>
          <button
            onClick={onWeekly}
            className="flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium transition-all duration-200"
            style={{
              backgroundColor: "rgba(0,212,168,0.12)",
              border: "1px solid rgba(0,212,168,0.25)",
              color: "#00d4a8",
              fontFamily: "'Outfit', sans-serif",
            }}
          >
            <Calendar size={15} />
            Semaine
          </button>
        </div>

        {/* Search bar */}
        <div
          className="flex items-center gap-3 px-4 py-3 rounded-2xl"
          style={{
            backgroundColor: "rgba(255,255,255,0.05)",
            border: "1px solid rgba(255,255,255,0.09)",
            backdropFilter: "blur(16px)",
          }}
        >
          <Search size={16} className="text-muted-foreground shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Rechercher un spot..."
            className="flex-1 bg-transparent text-foreground text-sm outline-none placeholder:text-muted-foreground"
            style={{ fontFamily: "'Outfit', sans-serif" }}
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery("")}>
              <X size={15} className="text-muted-foreground" />
            </button>
          )}
        </div>
      </div>

      {/* Map */}
      <div className="flex-1 relative overflow-hidden">
        {/* Ocean gradient base */}
        <div
          className="absolute inset-0"
          style={{
            background: "radial-gradient(ellipse at 20% 60%, #0a1f3d 0%, #070c16 55%, #04080f 100%)",
          }}
        />

        {/* Bathymetric depth rings */}
        {[...Array(6)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full"
            style={{
              width: `${(i + 1) * 140}px`,
              height: `${(i + 1) * 100}px`,
              left: `-${(i + 1) * 30}px`,
              top: `${30 + i * 12}%`,
              border: "1px solid rgba(0, 170, 255, 0.04)",
              transform: "rotate(-15deg)",
            }}
          />
        ))}

        {/* Coastline SVG */}
        <svg
          className="absolute inset-0 w-full h-full"
          viewBox="0 0 400 700"
          preserveAspectRatio="xMidYMid slice"
        >
          {/* Land fill */}
          <path
            d="M 148 0 C 148 0 152 40 155 80 C 158 120 160 145 158 170 C 156 195 154 215 150 240 C 146 265 140 280 138 310 C 136 340 138 360 135 390 C 132 420 128 440 122 465 C 116 490 110 510 105 535 C 100 560 96 580 90 610 C 84 640 78 665 70 700 L 400 700 L 400 0 Z"
            fill="rgba(15, 28, 50, 0.9)"
          />
          {/* Coastline stroke */}
          <path
            d="M 148 0 C 148 0 152 40 155 80 C 158 120 160 145 158 170 C 156 195 154 215 150 240 C 146 265 140 280 138 310 C 136 340 138 360 135 390 C 132 420 128 440 122 465 C 116 490 110 510 105 535 C 100 560 96 580 90 610 C 84 640 78 665 70 700"
            fill="none"
            stroke="rgba(0, 170, 255, 0.25)"
            strokeWidth="1.5"
            strokeDasharray="6 4"
          />
          {/* Shore glimmer */}
          <path
            d="M 148 0 C 148 0 152 40 155 80 C 158 120 160 145 158 170 C 156 195 154 215 150 240 C 146 265 140 280 138 310 C 136 340 138 360 135 390 C 132 420 128 440 122 465 C 116 490 110 510 105 535 C 100 560 96 580 90 610 C 84 640 78 665 70 700"
            fill="none"
            stroke="rgba(255, 255, 255, 0.06)"
            strokeWidth="3"
          />

          {/* Wave lines in ocean */}
          {[80, 160, 240, 320, 400, 480, 560].map((y, i) => (
            <path
              key={i}
              d={`M ${20 + i * 3} ${y} Q ${60 + i * 2} ${y - 8} ${100 + i} ${y}`}
              fill="none"
              stroke="rgba(0, 170, 255, 0.06)"
              strokeWidth="1"
            />
          ))}

          {/* Compass rose */}
          <g transform="translate(340, 60)">
            <circle cx="0" cy="0" r="22" fill="rgba(14,23,36,0.8)" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
            <text x="0" y="-11" textAnchor="middle" fill="rgba(255,255,255,0.6)" fontSize="8" fontFamily="Space Mono">N</text>
            <text x="0" y="15" textAnchor="middle" fill="rgba(255,255,255,0.3)" fontSize="7" fontFamily="Space Mono">S</text>
            <text x="12" y="3" textAnchor="middle" fill="rgba(255,255,255,0.3)" fontSize="7" fontFamily="Space Mono">E</text>
            <text x="-12" y="3" textAnchor="middle" fill="rgba(255,255,255,0.3)" fontSize="7" fontFamily="Space Mono">O</text>
            <line x1="0" y1="-8" x2="0" y2="8" stroke="rgba(0,212,168,0.6)" strokeWidth="1" />
            <line x1="-8" y1="0" x2="8" y2="0" stroke="rgba(255,255,255,0.3)" strokeWidth="1" />
          </g>

          {/* Scale */}
          <g transform="translate(30, 640)">
            <line x1="0" y1="0" x2="40" y2="0" stroke="rgba(255,255,255,0.3)" strokeWidth="1" />
            <line x1="0" y1="-3" x2="0" y2="3" stroke="rgba(255,255,255,0.3)" strokeWidth="1" />
            <line x1="40" y1="-3" x2="40" y2="3" stroke="rgba(255,255,255,0.3)" strokeWidth="1" />
            <text x="20" y="-6" textAnchor="middle" fill="rgba(255,255,255,0.3)" fontSize="7" fontFamily="Space Mono">50 km</text>
          </g>
        </svg>

        {/* Spot markers */}
        {spots.map((spot) => (
          <SpotMarker
            key={spot.id}
            spot={spot}
            onClick={() => onSpotClick(spot)}
            isSelected={selectedSpotId === spot.id}
          />
        ))}

        {/* Search results overlay */}
        {searchQuery && (
          <div
            className="absolute bottom-4 left-4 right-4 rounded-2xl overflow-hidden z-20"
            style={{
              backgroundColor: "rgba(14,23,36,0.95)",
              border: "1px solid rgba(255,255,255,0.1)",
              backdropFilter: "blur(20px)",
            }}
          >
            {spots.length === 0 ? (
              <div className="px-4 py-4 text-sm text-muted-foreground" style={{ fontFamily: "'Outfit', sans-serif" }}>
                Aucun spot trouvé
              </div>
            ) : (
              spots.map((spot, i) => (
                <button
                  key={spot.id}
                  onClick={() => { onSpotClick(spot); setSearchQuery(""); }}
                  className="w-full flex items-center justify-between px-4 py-3 transition-colors duration-150"
                  style={{
                    borderTop: i > 0 ? "1px solid rgba(255,255,255,0.06)" : "none",
                    fontFamily: "'Outfit', sans-serif",
                  }}
                >
                  <div className="flex items-center gap-3">
                    <MapPin size={14} style={{ color: getScoreColor(spot.score) }} />
                    <div className="text-left">
                      <div className="text-sm font-semibold text-foreground">{spot.name}</div>
                      <div className="text-xs text-muted-foreground">{spot.region}</div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span
                      className="text-sm font-bold px-2 py-0.5 rounded-lg"
                      style={{
                        color: getScoreColor(spot.score),
                        backgroundColor: `${getScoreColor(spot.score)}15`,
                        fontFamily: "'Space Mono', monospace",
                      }}
                    >
                      {spot.score}/10
                    </span>
                    <ChevronRight size={14} className="text-muted-foreground" />
                  </div>
                </button>
              ))
            )}
          </div>
        )}

        {/* Bottom gradient */}
        <div
          className="absolute bottom-0 left-0 right-0 h-24 pointer-events-none"
          style={{ background: "linear-gradient(to top, #070c16, transparent)" }}
        />

        {/* Legend */}
        {!searchQuery && (
          <div
            className="absolute bottom-4 left-4 right-4 flex items-center justify-center gap-4 z-10"
          >
            {[
              { label: "Excellent", score: 9 },
              { label: "Bon", score: 7 },
              { label: "Correct", score: 5 },
              { label: "Faible", score: 2 },
            ].map(({ label, score }) => (
              <div key={label} className="flex items-center gap-1.5">
                <div
                  className="w-2 h-2 rounded-full"
                  style={{ backgroundColor: getScoreColor(score) }}
                />
                <span className="text-muted-foreground" style={{ fontFamily: "'Space Mono', monospace", fontSize: "0.6rem" }}>
                  {label}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function DetailView({
  spot,
  onBack,
  initialDay = 0,
}: {
  spot: Spot;
  onBack: () => void;
  initialDay?: number;
}) {
  const [dayIndex, setDayIndex] = useState(initialDay);

  const score = spot.weeklyScores[dayIndex];
  const cond = useMemo(
    () => getDayConditions(score, dayIndex * 7 + spot.id.charCodeAt(0)),
    [score, dayIndex, spot.id]
  );
  const hourly = dayIndex === 0 ? spot.hourly : cond.hourly;
  const maxH = Math.max(...hourly.map((h) => h.height));
  const color = getScoreColor(score);
  const waveH = dayIndex === 0 ? spot.waves.height : cond.height;
  const period = dayIndex === 0 ? spot.waves.period : cond.period;
  const windSpeed = dayIndex === 0 ? spot.wind.speed : cond.windSpeed;
  const windGust = dayIndex === 0 ? spot.wind.gust : cond.gust;
  const waveDir = dayIndex === 0 ? spot.waves.direction : cond.waveDir;
  const windDir = dayIndex === 0 ? spot.wind.direction : cond.windDir;
  const waterTemp = dayIndex === 0 ? spot.water.temp : cond.waterTemp;
  const weather = dayIndex === 0 ? spot.weather : cond.weather;
  const tide = dayIndex === 0 ? spot.tide : cond.tide;

  return (
    <div className="flex flex-col h-full overflow-y-auto" style={{ scrollbarWidth: "none" }}>
      {/* Hero */}
      <div
        className="relative flex flex-col px-4 pt-14 pb-8"
        style={{
          background: `linear-gradient(160deg, ${color}18 0%, #070c16 60%)`,
          borderBottom: "1px solid rgba(255,255,255,0.06)",
        }}
      >
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-sm mb-8 transition-opacity duration-150 w-fit"
          style={{ color: "rgba(232,237,245,0.6)", fontFamily: "'Outfit', sans-serif" }}
        >
          <ArrowLeft size={16} />
          Retour
        </button>

        <div className="flex items-start justify-between mb-6">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <MapPin size={13} style={{ color }} />
              <span className="text-xs text-muted-foreground" style={{ fontFamily: "'Space Mono', monospace" }}>
                {spot.region}
              </span>
              <span
                className="text-xs px-2 py-0.5 rounded-full font-bold"
                style={{
                  backgroundColor: `${color}18`,
                  color,
                  fontFamily: "'Space Mono', monospace",
                  fontSize: "0.6rem",
                }}
              >
                {DAYS[dayIndex]}
              </span>
            </div>
            <h2
              className="text-3xl font-bold text-foreground"
              style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 800, letterSpacing: "-0.03em" }}
            >
              {spot.name}
            </h2>
          </div>
          <div className="flex flex-col items-center gap-1">
            <ScoreRing score={score} size={72} />
            <span className="text-xs font-bold" style={{ color, fontFamily: "'Space Mono', monospace", fontSize: "0.65rem" }}>
              {getScoreLabel(score)}
            </span>
          </div>
        </div>

        {/* Quick summary row */}
        <div className="flex items-center gap-4">
          <span className="text-2xl">{weather.emoji}</span>
          <div>
            <span className="text-lg font-bold text-foreground" style={{ fontFamily: "'Outfit', sans-serif" }}>
              {weather.temp}°C
            </span>
            <span className="text-sm text-muted-foreground ml-2" style={{ fontFamily: "'Outfit', sans-serif" }}>
              {weather.condition}
            </span>
          </div>
          <div className="ml-auto flex items-center gap-2 text-xs text-muted-foreground" style={{ fontFamily: "'Space Mono', monospace" }}>
            <Clock size={12} />
            {tide}
          </div>
        </div>
      </div>

      {/* Conditions grid */}
      <div className="px-4 py-5 flex flex-col gap-4">
        <h3
          className="text-xs uppercase tracking-widest text-muted-foreground"
          style={{ fontFamily: "'Space Mono', monospace", fontSize: "0.65rem" }}
        >
          Conditions du jour
        </h3>
        <div className="grid grid-cols-2 gap-3">
          <StatCard
            icon={<span style={{ fontSize: "1.1rem" }}>🌊</span>}
            label="Hauteur"
            value={`${waveH} m`}
            sub={`Période ${period}s`}
            color={color}
          />
          <StatCard
            icon={<Wind size={16} />}
            label="Vent"
            value={`${windSpeed} kn`}
            sub={`Rafales ${windGust} kn`}
            color="#00aaff"
          />
          <StatCard
            icon={<Compass size={16} />}
            label="Direction"
            value={waveDir}
            sub={`Vent ${windDir}`}
            color="#a78bfa"
          />
          <StatCard
            icon={<Thermometer size={16} />}
            label="Eau"
            value={`${waterTemp}°C`}
            sub="Température surf"
            color="#ffb84d"
          />
        </div>
      </div>

      {/* Hourly forecast */}
      <div className="px-4 pb-5 flex flex-col gap-4">
        <h3
          className="text-xs uppercase tracking-widest text-muted-foreground"
          style={{ fontFamily: "'Space Mono', monospace", fontSize: "0.65rem" }}
        >
          Prévisions horaires
        </h3>
        <div
          className="p-4 rounded-2xl"
          style={{ backgroundColor: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}
        >
          <div className="flex gap-1.5">
            {hourly.map((h) => (
              <HourlyBar key={h.hour} h={h} maxH={maxH} />
            ))}
          </div>
          <div className="flex items-center justify-between mt-3">
            <span className="text-xs text-muted-foreground" style={{ fontFamily: "'Space Mono', monospace", fontSize: "0.6rem" }}>
              Hauteur de vague (m)
            </span>
            <span className="text-xs text-muted-foreground" style={{ fontFamily: "'Space Mono', monospace", fontSize: "0.6rem" }}>
              Score /10
            </span>
          </div>
        </div>
      </div>

      {/* Wind detail */}
      <div className="px-4 pb-5 flex flex-col gap-4">
        <h3
          className="text-xs uppercase tracking-widest text-muted-foreground"
          style={{ fontFamily: "'Space Mono', monospace", fontSize: "0.65rem" }}
        >
          Vent
        </h3>
        <div
          className="p-4 rounded-2xl flex items-center gap-4"
          style={{ backgroundColor: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}
        >
          {/* Wind rose */}
          <div className="relative w-16 h-16 shrink-0">
            <svg viewBox="0 0 64 64" className="w-full h-full">
              <circle cx="32" cy="32" r="28" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="1" />
              <circle cx="32" cy="32" r="4" fill="rgba(0,170,255,0.5)" />
              <line x1="32" y1="32" x2="32" y2="8" stroke="#00aaff" strokeWidth="2" strokeLinecap="round" />
              <text x="32" y="6" textAnchor="middle" fill="rgba(255,255,255,0.5)" fontSize="6" fontFamily="Space Mono">N</text>
              <text x="32" y="62" textAnchor="middle" fill="rgba(255,255,255,0.2)" fontSize="6" fontFamily="Space Mono">S</text>
              <text x="60" y="34" textAnchor="middle" fill="rgba(255,255,255,0.2)" fontSize="6" fontFamily="Space Mono">E</text>
              <text x="4" y="34" textAnchor="middle" fill="rgba(255,255,255,0.2)" fontSize="6" fontFamily="Space Mono">O</text>
            </svg>
          </div>
          <div className="flex-1">
            <div className="flex justify-between mb-3">
              <div>
                <div className="text-xs text-muted-foreground mb-1" style={{ fontFamily: "'Space Mono', monospace", fontSize: "0.65rem" }}>
                  Vitesse
                </div>
                <div className="text-2xl font-bold text-foreground" style={{ fontFamily: "'Outfit', sans-serif", color: "#00aaff" }}>
                  {windSpeed} <span className="text-sm font-normal text-muted-foreground">kn</span>
                </div>
              </div>
              <div>
                <div className="text-xs text-muted-foreground mb-1" style={{ fontFamily: "'Space Mono', monospace", fontSize: "0.65rem" }}>
                  Rafales
                </div>
                <div className="text-2xl font-bold" style={{ fontFamily: "'Outfit', sans-serif", color: "#ffb84d" }}>
                  {windGust} <span className="text-sm font-normal text-muted-foreground">kn</span>
                </div>
              </div>
            </div>
            {/* Speed bar */}
            <div className="h-1.5 rounded-full overflow-hidden" style={{ backgroundColor: "rgba(255,255,255,0.08)" }}>
              <div
                className="h-full rounded-full"
                style={{
                  width: `${(windSpeed / 40) * 100}%`,
                  background: "linear-gradient(to right, #00aaff, #00d4a8)",
                }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Week mini */}
      <div className="px-4 pb-8 flex flex-col gap-4">
        <h3
          className="text-xs uppercase tracking-widest text-muted-foreground"
          style={{ fontFamily: "'Space Mono', monospace", fontSize: "0.65rem" }}
        >
          Cette semaine
        </h3>
        <div
          className="flex gap-2 p-4 rounded-2xl"
          style={{ backgroundColor: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.07)" }}
        >
          {spot.weeklyScores.map((s, i) => {
            const c = getScoreColor(s);
            const isActive = i === dayIndex;
            return (
              <button
                key={i}
                onClick={() => setDayIndex(i)}
                className="flex flex-col items-center gap-2 flex-1 transition-all duration-200"
              >
                <span
                  className="text-xs font-bold"
                  style={{
                    color: isActive ? c : "rgba(232,237,245,0.35)",
                    fontFamily: "'Space Mono', monospace",
                    fontSize: "0.6rem",
                  }}
                >
                  {DAYS[i]}
                </span>
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border transition-all duration-200"
                  style={{
                    backgroundColor: isActive ? `${c}25` : "rgba(255,255,255,0.03)",
                    borderColor: isActive ? c : "rgba(255,255,255,0.07)",
                    color: isActive ? c : "rgba(232,237,245,0.4)",
                    fontFamily: "'Space Mono', monospace",
                    fontSize: "0.7rem",
                    boxShadow: isActive ? `0 0 10px ${c}35` : "none",
                    transform: isActive ? "scale(1.1)" : "scale(1)",
                  }}
                >
                  {s}
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function WeeklyView({ spots, onBack, onSpotClick }: { spots: Spot[]; onBack: () => void; onSpotClick: (spot: Spot, dayIndex: number) => void }) {
  return (
    <div className="flex flex-col h-full overflow-y-auto" style={{ scrollbarWidth: "none" }}>
      {/* Header */}
      <div className="px-4 pt-14 pb-4" style={{ borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-sm mb-6"
          style={{ color: "rgba(232,237,245,0.6)", fontFamily: "'Outfit', sans-serif" }}
        >
          <ArrowLeft size={16} />
          Retour carte
        </button>
        <div className="flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-bold text-foreground" style={{ fontFamily: "'Outfit', sans-serif", fontWeight: 800, letterSpacing: "-0.03em" }}>
              Prévisions
            </h2>
            <p className="text-xs text-muted-foreground mt-1" style={{ fontFamily: "'Space Mono', monospace" }}>
              7 jours · Tous les spots
            </p>
          </div>
          <TrendingUp size={20} style={{ color: "#00d4a8" }} />
        </div>

        {/* Day headers */}
        <div className="flex gap-2 mt-5">
          <div className="w-24 shrink-0" />
          {DAYS.map((d, i) => (
            <div
              key={i}
              className="flex-1 text-center py-1 rounded-lg"
              style={{
                fontFamily: "'Space Mono', monospace",
                fontSize: "0.65rem",
                fontWeight: 700,
                color: i === 0 ? "#00d4a8" : "rgba(232,237,245,0.4)",
                backgroundColor: i === 0 ? "rgba(0,212,168,0.08)" : "transparent",
              }}
            >
              {d}
            </div>
          ))}
        </div>
      </div>

      {/* Spot rows */}
      <div className="flex flex-col divide-y" style={{ borderColor: "rgba(255,255,255,0.05)" }}>
        {spots.map((spot) => (
          <div
            key={spot.id}
            className="flex items-center gap-2 px-4 py-4 w-full"
          >
            {/* Spot label — click to open today */}
            <button
              onClick={() => onSpotClick(spot, 0)}
              className="w-24 shrink-0 text-left"
              style={{ fontFamily: "'Outfit', sans-serif" }}
            >
              <div className="text-sm font-semibold text-foreground truncate">{spot.name}</div>
              <div className="text-xs text-muted-foreground">{spot.region}</div>
            </button>

            {/* Weekly score circles — each day clickable */}
            {spot.weeklyScores.map((s, i) => {
              const c = getScoreColor(s);
              return (
                <button
                  key={i}
                  onClick={() => onSpotClick(spot, i)}
                  className="flex-1 flex justify-center transition-transform duration-150 active:scale-90"
                >
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border transition-all duration-150"
                    style={{
                      backgroundColor: i === 0 ? `${c}22` : "rgba(255,255,255,0.03)",
                      borderColor: i === 0 ? c : "rgba(255,255,255,0.08)",
                      color: c,
                      fontFamily: "'Space Mono', monospace",
                      fontSize: "0.7rem",
                      opacity: i === 0 ? 1 : 0.7,
                      boxShadow: i === 0 ? `0 0 10px ${c}30` : "none",
                    }}
                  >
                    {s}
                  </div>
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* Best day callout */}
      <div className="px-4 py-5 mt-2">
        <div
          className="p-4 rounded-2xl flex items-center gap-4"
          style={{
            background: "linear-gradient(135deg, rgba(0,212,168,0.12) 0%, rgba(0,170,255,0.08) 100%)",
            border: "1px solid rgba(0,212,168,0.2)",
          }}
        >
          <Zap size={20} style={{ color: "#00d4a8" }} />
          <div>
            <div className="text-sm font-bold text-foreground" style={{ fontFamily: "'Outfit', sans-serif" }}>
              Meilleure session de la semaine
            </div>
            <div className="text-xs text-muted-foreground mt-0.5" style={{ fontFamily: "'Space Mono', monospace" }}>
              Sam · Hossegor · Score 9/10
            </div>
          </div>
          <ChevronRight size={16} className="ml-auto" style={{ color: "#00d4a8" }} />
        </div>
      </div>
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────

export default function App() {
  const [view, setView] = useState<"map" | "detail" | "weekly">("map");
  const [selectedSpot, setSelectedSpot] = useState<Spot | null>(null);
  const [selectedDay, setSelectedDay] = useState(0);
  const [searchQuery, setSearchQuery] = useState("");

  const filteredSpots = useMemo(() => {
    if (!searchQuery.trim()) return SPOTS;
    const q = searchQuery.toLowerCase();
    return SPOTS.filter(
      (s) => s.name.toLowerCase().includes(q) || s.region.toLowerCase().includes(q)
    );
  }, [searchQuery]);

  function handleSpotClick(spot: Spot, day = 0) {
    setSelectedSpot(spot);
    setSelectedDay(day);
    setView("detail");
    setSearchQuery("");
  }

  return (
    <div
      className="h-full w-full flex justify-center bg-background"
      style={{ fontFamily: "'Outfit', sans-serif" }}
    >
      {/* Mobile frame */}
      <div
        className="relative w-full max-w-sm h-full overflow-hidden"
        style={{ backgroundColor: "#070c16" }}
      >
        {/* Views */}
        <div
          className="absolute inset-0 transition-transform duration-300 ease-in-out"
          style={{ transform: view === "map" ? "translateX(0)" : "translateX(-100%)" }}
        >
          <MapView
            spots={searchQuery ? filteredSpots : SPOTS}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            onSpotClick={handleSpotClick}
            selectedSpotId={selectedSpot?.id ?? null}
            onWeekly={() => setView("weekly")}
          />
        </div>

        <div
          className="absolute inset-0 transition-transform duration-300 ease-in-out"
          style={{ transform: view === "detail" ? "translateX(0)" : "translateX(100%)" }}
        >
          {selectedSpot && (
            <DetailView
              spot={selectedSpot}
              onBack={() => setView("map")}
              initialDay={selectedDay}
            />
          )}
        </div>

        <div
          className="absolute inset-0 transition-transform duration-300 ease-in-out"
          style={{ transform: view === "weekly" ? "translateX(0)" : "translateX(100%)" }}
        >
          <WeeklyView
            spots={SPOTS}
            onBack={() => setView("map")}
            onSpotClick={(spot, day) => { setSelectedSpot(spot); setSelectedDay(day ?? 0); setView("detail"); }}
          />
        </div>
      </div>
    </div>
  );
}
